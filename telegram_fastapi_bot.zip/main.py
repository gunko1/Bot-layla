import os
import logging
from fastapi import FastAPI, Request
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
from dotenv import load_dotenv
import openai

# Load .env
load_dotenv()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
TON_WALLET = os.getenv("TON_WALLET")
WEBHOOK_PATH = "/webhook"

openai.api_key = OPENAI_API_KEY

# In-memory user consent storage
user_consents = set()

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# FastAPI app
app = FastAPI()

# Telegram bot application
telegram_app = Application.builder().token(TELEGRAM_TOKEN).build()

# Keyboard layout
keyboard = [
    ["💬 AI-фантазия", "🖼 AI-образ"],
    ["🔊 AI-голос"],
    ["💸 Оплатить в TON"],
]
reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


# Handlers
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Привет! Подтверди, что тебе 18+, отправив /consent18."
    )


async def consent(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_consents.add(user_id)
    await update.message.reply_text(
        "Доступ открыт. Выберите опцию:", reply_markup=reply_markup
    )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in user_consents:
        await update.message.reply_text("Сначала отправь /consent18.")
        return

    text = update.message.text

    if text == "💬 AI-фантазия":
        await update.message.reply_text("Опиши свою фантазию.")
        context.user_data["mode"] = "fantasy"

    elif text == "🖼 AI-образ":
        await update.message.reply_text("Опиши изображение.")
        context.user_data["mode"] = "image"

    elif text == "🔊 AI-голос":
        await update.message.reply_text("🔊 Заглушка голосового файла (MP3)")
        await update.message.reply_audio(audio="https://example.com/sample.mp3")

    elif text == "💸 Оплатить в TON":
        await update.message.reply_text(
            f"Отправьте оплату на TON-кошелёк: `{TON_WALLET}`\n\nПосле оплаты пришлите TxID.",
            parse_mode="Markdown",
        )
        context.user_data["mode"] = "txid"

    elif context.user_data.get("mode") == "fantasy":
        prompt = text
        await update.message.reply_text("Генерирую фантазию...")

        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "Ты креативный AI."},
                    {"role": "user", "content": prompt},
                ],
            )
            result = response.choices[0].message.content
            await update.message.reply_text(result)
        except Exception as e:
            logger.error(e)
            await update.message.reply_text("Произошла ошибка при генерации текста.")

        context.user_data["mode"] = None

    elif context.user_data.get("mode") == "image":
        description = text
        await update.message.reply_photo(photo="https://example.com/image-placeholder.jpg")
        context.user_data["mode"] = None

    elif context.user_data.get("mode") == "txid":
        txid = text.strip()
        await update.message.reply_text(f"TxID `{txid}` принят. Спасибо за оплату!", parse_mode="Markdown")
        context.user_data["mode"] = None

    else:
        await update.message.reply_text("Выберите опцию из меню.")


@app.post(WEBHOOK_PATH)
async def telegram_webhook(req: Request):
    data = await req.json()
    update = Update.de_json(data, telegram_app.bot)
    await telegram_app.update_queue.put(update)
    return {"ok": True}


telegram_app.add_handler(CommandHandler("start", start))
telegram_app.add_handler(CommandHandler("consent18", consent))
telegram_app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))


@app.on_event("startup")
async def on_startup():
    webhook_url = os.getenv("WEBHOOK_URL")
    if webhook_url:
        full_url = webhook_url + WEBHOOK_PATH
        await telegram_app.bot.set_webhook(full_url)
        logger.info(f"Webhook set to: {full_url}")
    telegram_app.run_polling(stop_signals=None)
